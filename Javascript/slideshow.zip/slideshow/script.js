var myImage = document.getElementById ("mainImage");

var imageArray = ["IslandOasis.jpg", "LakeShore.jpg", "center.jpg", "MountainView.jpg", "NewHaven.jpg", "SanDiego.jpg"];

var imageIndex = 2;

function changeImageForward () {
    imageIndex++;
     if (imageIndex > imageArray.length-1) {
        imageIndex = 0;
     }
    myImage.setAttribute ("src", imageArray[imageIndex]);
}

function changeImageBackward () {
    imageIndex--;
    if (imageIndex < 0) {
        imageIndex = imageArray.length-1;
    }
    myImage.setAttribute ("src", imageArray[imageIndex]);
}

function next () {
    var nextButton = document.getElementById ("next");
    nextButton.onclick = function () {
        changeImageForward();
    };
}

function previous () {
    var previousButton = document.getElementById ("previous");
    previousButton.onclick = function () {
        changeImageBackward();
    };
}

previous ();
next ();


